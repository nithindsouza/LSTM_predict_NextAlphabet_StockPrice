My GitHub link to this repository to view notebook without compiling
link: https://github.com/nithindsouza/RNN-LSTM-GPU